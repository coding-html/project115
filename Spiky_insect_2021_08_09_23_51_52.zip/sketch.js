function setup() 
{
 canvas=createCanvas(300,300)
  canvas.center();
  canvas.position(300,200);
}

function draw() {

}
function preload()
{
  
}
function save()
{
  
}